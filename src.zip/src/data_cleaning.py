
import pandas as pd
import numpy as np
from datetime import datetime
import config
from src.utils import load_data, save_data, detect_outliers, print_section

def clean_orders_data():
    """Limpa e processa dados de pedidos"""
    print_section("LIMPEZA DE DADOS")
    
    # Carregar datasets
    orders = load_data('olist_orders_dataset.csv', config.DATA_RAW)
    order_items = load_data('olist_order_items_dataset.csv', config.DATA_RAW)
    customers = load_data('olist_customers_dataset.csv', config.DATA_RAW)
    products = load_data('olist_products_dataset.csv', config.DATA_RAW)
    payments = load_data('olist_order_payments_dataset.csv', config.DATA_RAW)
    
    # 1. Verificar missing values
    print("\n📊 Missing Values:")
    print(orders.isnull().sum())
    
    # 2. Converter datas
    print("\n🕐 Convertendo datas...")
    date_columns = [
        'order_purchase_timestamp',
        'order_approved_at',
        'order_delivered_customer_date',
        'order_estimated_delivery_date'
    ]
    for col in date_columns:
        if col in orders.columns:
            orders[col] = pd.to_datetime(orders[col], errors='coerce')
    
    # 3. Filtrar apenas pedidos válidos
    print("\n🔍 Filtrando pedidos válidos...")
    initial_count = len(orders)
    orders_clean = orders[orders['order_status'].isin(['delivered', 'shipped'])].copy()
    print(f"   Pedidos removidos: {initial_count - len(orders_clean)}")
    
    # 4. Criar features temporais
    print("\n📅 Criando features temporais...")
    orders_clean['order_date'] = orders_clean['order_purchase_timestamp'].dt.date
    orders_clean['order_year'] = orders_clean['order_purchase_timestamp'].dt.year
    orders_clean['order_month'] = orders_clean['order_purchase_timestamp'].dt.month
    orders_clean['order_year_month'] = orders_clean['order_purchase_timestamp'].dt.to_period('M')
    orders_clean['order_weekday'] = orders_clean['order_purchase_timestamp'].dt.dayofweek
    
    # Calcular dias de entrega
    orders_clean['delivery_days'] = (
        orders_clean['order_delivered_customer_date'] - 
        orders_clean['order_purchase_timestamp']
    ).dt.days
    
    # 5. Detectar anomalias em valores
    print("\n🚨 Detectando anomalias...")
    order_values = order_items.groupby('order_id')['price'].sum()
    outliers = detect_outliers(order_values, threshold=config.OUTLIER_THRESHOLD)
    print(f"   Outliers detectados: {len(outliers)}")
    print(f"   Exemplo: {outliers.head()}")
    
    # 6. Merge de todas as tabelas
    print("\n🔗 Fazendo merge das tabelas...")
    df_full = (
        orders_clean
        .merge(order_items, on='order_id', how='left')
        .merge(customers, on='customer_id', how='left')
        .merge(products, on='product_id', how='left')
    )
    
    # Agregar pagamentos por pedido
    payments_agg = payments.groupby('order_id').agg({
        'payment_value': 'sum',
        'payment_type': lambda x: x.mode()[0] if len(x) > 0 else 'unknown'
    }).reset_index()
    
    df_full = df_full.merge(payments_agg, on='order_id', how='left')
    
    # 7. Criar métricas agregadas
    print("\n📈 Criando métricas agregadas...")
    df_full['total_order_value'] = df_full.groupby('order_id')['price'].transform('sum')
    df_full['total_items'] = df_full.groupby('order_id')['order_id'].transform('count')
    df_full['avg_item_price'] = df_full['total_order_value'] / df_full['total_items']
    
    # 8. Remover duplicatas
    print("\n🧹 Removendo duplicatas...")
    initial_rows = len(df_full)
    df_full = df_full.drop_duplicates(subset=['order_id', 'product_id'])
    print(f"   Linhas removidas: {initial_rows - len(df_full)}")
    
    # 9. Estatísticas finais
    print("\n📊 Resumo Final:")
    print(f"   Total de pedidos: {df_full['order_id'].nunique():,}")
    print(f"   Total de clientes: {df_full['customer_id'].nunique():,}")
    print(f"   Total de produtos: {df_full['product_id'].nunique():,}")
    print(f"   Período: {df_full['order_date'].min()} a {df_full['order_date'].max()}")
    print(f"   Receita total: €{df_full['price'].sum():,.2f}")
    
    # 10. Salvar dados limpos
    save_data(df_full, 'ecommerce_clean.csv', config.DATA_PROCESSED)
    
    # Salvar também tabelas individuais para SQL
    orders_clean.to_csv(f"{config.DATA_SQL}/orders.csv", index=False)
    customers.to_csv(f"{config.DATA_SQL}/customers.csv", index=False)
    products.to_csv(f"{config.DATA_SQL}/products.csv", index=False)
    order_items.to_csv(f"{config.DATA_SQL}/order_items.csv", index=False)
    payments_agg.to_csv(f"{config.DATA_SQL}/payments.csv", index=False)
    
    print("\n✅ Limpeza de dados concluída!")
    return df_full

if __name__ == "__main__":
    clean_orders_data()