import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime

def load_data(filename, path):
    """Carrega CSV com tratamento de erro"""
    try:
        filepath = f"{path}/{filename}"
        df = pd.read_csv(filepath)
        print(f"✓ {filename} carregado: {len(df)} linhas")
        return df
    except FileNotFoundError:
        print(f"✗ Erro: {filename} não encontrado em {path}")
        return None

def save_data(df, filename, path):
    """Salva DataFrame como CSV"""
    filepath = f"{path}/{filename}"
    df.to_csv(filepath, index=False)
    print(f"✓ {filename} salvo em {path}")

def detect_outliers(series, threshold=3):
    """Detecta outliers usando IQR"""
    Q1 = series.quantile(0.25)
    Q3 = series.quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - threshold * IQR
    upper_bound = Q3 + threshold * IQR
    outliers = series[(series < lower_bound) | (series > upper_bound)]
    return outliers

def print_section(title):
    """Print formatado para secções"""
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)

def save_plot(filename):
    """Salva gráfico com configurações padrão"""
    from config import OUTPUTS_PLOTS
    filepath = f"{OUTPUTS_PLOTS}/{filename}"
    plt.tight_layout()
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    print(f"✓ Gráfico salvo: {filename}")
    plt.close()