
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import config
from src.utils import load_data, save_data, print_section, save_plot

def abc_analysis(df):
    """Análise ABC de produtos"""
    print_section("ANÁLISE ABC DE PRODUTOS")
    
    # Agrupar por categoria
    print("\n📦 Agrupando produtos...")
    product_sales = df.groupby('product_category_name').agg({
        'price': 'sum',
        'order_id': 'nunique'
    }).reset_index()
    
    product_sales.columns = ['category', 'total_revenue', 'total_orders']
    
    # Ordenar por receita
    product_sales = product_sales.sort_values('total_revenue', ascending=False)
    
    # Calcular percentagens
    total_revenue = product_sales['total_revenue'].sum()
    product_sales['pct_revenue'] = (product_sales['total_revenue'] / total_revenue * 100)
    product_sales['cumulative_pct'] = product_sales['pct_revenue'].cumsum()
    
    # Classificar ABC
    def classify_abc(cumulative_pct):
        if cumulative_pct <= 70:
            return 'A'
        elif cumulative_pct <= 90:
            return 'B'
        else:
            return 'C'
    
    product_sales['abc_class'] = product_sales['cumulative_pct'].apply(classify_abc)
    
    # Estatísticas
    print("\n📊 Distribuição ABC:")
    abc_stats = product_sales.groupby('abc_class').agg({
        'category': 'count',
        'total_revenue': 'sum',
        'pct_revenue': 'sum'
    })
    print(abc_stats)
    
    # Visualizações
    create_abc_visualizations(product_sales)
    
    # Salvar
    save_data(product_sales, 'abc_analysis.csv', config.OUTPUTS_REPORTS)
    
    print("\n✅ Análise ABC concluída!")
    return product_sales

def create_abc_visualizations(product_sales):
    """Cria visualizações ABC"""
    print("\n📊 Gerando visualizações...")
    
    # 1. Curva ABC (Pareto)
    plt.figure(figsize=(14, 6))
    
    # Barras de receita
    x = range(len(product_sales))
    plt.bar(x, product_sales['pct_revenue'], color='steelblue', alpha=0.7, label='% Receita')
    
    # Linha cumulativa
    plt.plot(x, product_sales['cumulative_pct'], color='red', marker='o', 
             linewidth=2, markersize=4, label='% Cumulativa')
    
    # Linhas de classificação
    plt.axhline(y=70, color='green', linestyle='--', alpha=0.5, label='Classe A (70%)')
    plt.axhline(y=90, color='orange', linestyle='--', alpha=0.5, label='Classe B (90%)')
    
    plt.xlabel('Categorias de Produtos', fontsize=12)
    plt.ylabel('Percentagem (%)', fontsize=12)
    plt.title('Análise ABC - Curva de Pareto', fontsize=14, weight='bold')
    plt.legend()
    plt.grid(axis='y', alpha=0.3)
    save_plot('abc_pareto_curve.png')
    
    # 2. Distribuição por classe
    plt.figure(figsize=(10, 6))
    class_counts = product_sales['abc_class'].value_counts()
    colors = ['#2ecc71', '#f39c12', '#e74c3c']
    plt.pie(class_counts, labels=class_counts.index, autopct='%1.1f%%',
            colors=colors, startangle=90)
    plt.title('Distribuição de Produtos por Classe ABC', fontsize=14, weight='bold')
    save_plot('abc_distribution.png')
    
    # 3. Top 10 produtos (Classe A)
    plt.figure(figsize=(12, 6))
    top10 = product_sales.head(10)
    plt.barh(range(len(top10)), top10['total_revenue'], color='steelblue')
    plt.yticks(range(len(top10)), top10['category'])
    plt.xlabel('Receita Total (€)', fontsize=12)
    plt.title('Top 10 Categorias de Produtos (Classe A)', fontsize=14, weight='bold')
    plt.gca().invert_yaxis()
    for i, v in enumerate(top10['total_revenue']):
        plt.text(v, i, f' €{v:,.0f}', va='center')
    save_plot('abc_top10_products.png')

if __name__ == "__main__":
    df = load_data('ecommerce_clean.csv', config.DATA_PROCESSED)
    abc_analysis(df)