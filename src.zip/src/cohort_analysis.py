"""
Análise de Cohort (Retention Analysis)
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import config
from src.utils import load_data, save_data, print_section, save_plot

def cohort_retention_analysis(df):
    """Análise de retenção por cohort"""
    print_section("ANÁLISE DE COHORT")
    
    # Verificar colunas disponíveis
    print("\n🔍 Verificando colunas disponíveis...")
    
    # Identificar coluna de customer_id correta
    customer_col = None
    if 'customer_unique_id' in df.columns:
        customer_col = 'customer_unique_id'
    elif 'customer_id' in df.columns:
        customer_col = 'customer_id'
    else:
        print("❌ ERRO: Nenhuma coluna de customer encontrada!")
        return None
    
    print(f"✓ Usando coluna: {customer_col}")
    
    # Preparar dados
    print("\n📅 Preparando dados de cohort...")
    df['order_month'] = df['order_purchase_timestamp'].dt.to_period('M')
    
    # Identificar primeiro pedido de cada cliente (cohort)
    cohort_data = df.groupby(customer_col)['order_month'].min().reset_index()
    cohort_data.columns = ['customer_unique_id', 'cohort_month']
    
    # Merge com dados completos (mantendo o nome original da coluna)
    df_cohort = df.merge(
        cohort_data, 
        on='customer_unique_id',
        how='left'
    )
    
    # Calcular período desde primeira compra
    df_cohort['period_number'] = (
        df_cohort['order_month'] - df_cohort['cohort_month']
    ).apply(lambda x: x.n)
    
    # Contar clientes únicos por cohort e período
    print("\n🔢 Calculando retenção...")
    cohort_counts = df_cohort.groupby(['cohort_month', 'period_number']).agg({
        customer_col: 'nunique'  # Usar a coluna original
    }).reset_index()
    
    cohort_counts.columns = ['cohort_month', 'period_number', 'customer_count']
    
    # Criar pivot table
    cohort_pivot = cohort_counts.pivot(
        index='cohort_month',
        columns='period_number',
        values='customer_count'
    )
    
    # Calcular percentagem de retenção
    cohort_size = cohort_pivot.iloc[:, 0]
    retention = cohort_pivot.divide(cohort_size, axis=0) * 100
    
    # Estatísticas de retenção
    print("\n📊 Estatísticas de Retenção:")
    
    if 1 in retention.columns:
        print(f"   Retenção média Mês 1: {retention[1].mean():.1f}%")
    if 3 in retention.columns:
        print(f"   Retenção média Mês 3: {retention[3].mean():.1f}%")
    if 6 in retention.columns:
        print(f"   Retenção média Mês 6: {retention[6].mean():.1f}%")
    
    # Calcular Customer Lifetime
    avg_lifetime = df_cohort.groupby(customer_col)['period_number'].max().mean()
    print(f"   Customer Lifetime médio: {avg_lifetime:.1f} meses")
    
    # Visualizações
    create_cohort_visualizations(retention, cohort_pivot)
    
    # Salvar resultados
    retention.to_csv(f"{config.OUTPUTS_REPORTS}/cohort_retention.csv")
    cohort_pivot.to_csv(f"{config.OUTPUTS_REPORTS}/cohort_counts.csv")
    
    print("\n✅ Análise de cohort concluída!")
    return retention

def create_cohort_visualizations(retention, cohort_counts):
    """Cria visualizações de cohort"""
    print("\n📊 Gerando visualizações...")
    
    # 1. Heatmap de retenção
    plt.figure(figsize=(14, 8))
    sns.heatmap(
        retention, 
        annot=True, 
        fmt='.0f', 
        cmap='RdYlGn',
        cbar_kws={'label': 'Retenção (%)'},
        vmin=0,
        vmax=100
    )
    plt.title('Cohort Retention Analysis (%)', fontsize=14, weight='bold')
    plt.ylabel('Cohort Month', fontsize=12)
    plt.xlabel('Períodos desde primeira compra', fontsize=12)
    plt.yticks(rotation=0)
    plt.tight_layout()
    save_plot('cohort_retention_heatmap.png')
    
    # 2. Linha de retenção por cohort (primeiros 6 cohorts)
    plt.figure(figsize=(12, 6))
    num_cohorts = min(6, len(retention))
    for i, cohort in enumerate(retention.index[:num_cohorts]):
        plt.plot(retention.loc[cohort], marker='o', label=str(cohort))
    plt.xlabel('Meses desde primeira compra', fontsize=12)
    plt.ylabel('Retenção (%)', fontsize=12)
    plt.title('Curva de Retenção por Cohort', fontsize=14, weight='bold')
    plt.legend(title='Cohort', bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.grid(alpha=0.3)
    plt.ylim(0, 100)
    plt.tight_layout()
    save_plot('cohort_retention_curves.png')
    
    # 3. Média de retenção por período
    plt.figure(figsize=(10, 6))
    avg_retention = retention.mean()
    plt.bar(range(len(avg_retention)), avg_retention, color='steelblue', alpha=0.8)
    plt.xlabel('Meses desde primeira compra', fontsize=12)
    plt.ylabel('Retenção Média (%)', fontsize=12)
    plt.title('Retenção Média por Período', fontsize=14, weight='bold')
    plt.grid(axis='y', alpha=0.3)
    for i, v in enumerate(avg_retention):
        plt.text(i, v + 1, f'{v:.1f}%', ha='center', va='bottom')
    plt.tight_layout()
    save_plot('cohort_avg_retention.png')

if __name__ == "__main__":
    df = load_data('ecommerce_clean.csv', config.DATA_PROCESSED)
    df['order_purchase_timestamp'] = pd.to_datetime(df['order_purchase_timestamp'])
    cohort_retention_analysis(df)