
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import config
from src.utils import load_data, save_data, print_section, save_plot

def calculate_rfm(df):
    """Calcula scores RFM para cada cliente"""
    print_section("ANÁLISE RFM")
    
    # Data de referência (última data + 1 dia)
    reference_date = df['order_date'].max() + pd.Timedelta(days=1)
    print(f"📅 Data de referência: {reference_date}")
    
    # Calcular métricas RFM
    print("\n🔢 Calculando métricas RFM...")
    rfm = df.groupby('customer_unique_id').agg({
        'order_date': lambda x: (reference_date - x.max()).days,  # Recency
        'order_id': 'nunique',  # Frequency
        'price': 'sum'  # Monetary
    }).reset_index()
    
    rfm.columns = ['customer_id', 'recency', 'frequency', 'monetary']
    
    # Criar scores (1-5, sendo 5 o melhor)
    print("\n🎯 Criando scores RFM...")
    rfm['r_score'] = pd.qcut(
        rfm['recency'], 
        config.RFM_QUANTILES, 
        labels=[5, 4, 3, 2, 1]
    )
    rfm['f_score'] = pd.qcut(
        rfm['frequency'].rank(method='first'), 
        config.RFM_QUANTILES, 
        labels=[1, 2, 3, 4, 5]
    )
    rfm['m_score'] = pd.qcut(
        rfm['monetary'], 
        config.RFM_QUANTILES, 
        labels=[1, 2, 3, 4, 5]
    )
    
    # Converter para int
    rfm['r_score'] = rfm['r_score'].astype(int)
    rfm['f_score'] = rfm['f_score'].astype(int)
    rfm['m_score'] = rfm['m_score'].astype(int)
    
    # Score combinado
    rfm['rfm_score'] = (
        rfm['r_score'].astype(str) + 
        rfm['f_score'].astype(str) + 
        rfm['m_score'].astype(str)
    )
    
    # Segmentação de clientes
    print("\n👥 Segmentando clientes...")
    rfm['segment'] = rfm.apply(segment_customer, axis=1)
    
    # Estatísticas por segmento
    segment_stats = rfm.groupby('segment').agg({
        'customer_id': 'count',
        'monetary': ['mean', 'sum'],
        'frequency': 'mean',
        'recency': 'mean'
    }).round(2)
    
    segment_stats.columns = ['count', 'avg_monetary', 'total_value', 'avg_frequency', 'avg_recency']
    segment_stats = segment_stats.sort_values('total_value', ascending=False)
    
    print("\n📊 Estatísticas por Segmento:")
    print(segment_stats)
    
    # Visualizações
    create_rfm_visualizations(rfm, segment_stats)
    
    # Salvar resultados
    save_data(rfm, 'rfm_segmentation.csv', config.DATA_PROCESSED)
    segment_stats.to_csv(f"{config.OUTPUTS_REPORTS}/rfm_segment_stats.csv")
    
    print("\n✅ Análise RFM concluída!")
    return rfm

def segment_customer(row):
    """Define segmento baseado em scores RFM"""
    r, f, m = row['r_score'], row['f_score'], row['m_score']
    
    if r >= 4 and f >= 4:
        return 'Champions'
    elif r >= 4 and f >= 2:
        return 'Loyal Customers'
    elif r >= 3 and f >= 3:
        return 'Potential Loyalists'
    elif r >= 4 and f < 2:
        return 'New Customers'
    elif r >= 3 and f < 2:
        return 'Promising'
    elif r < 3 and f >= 4:
        return 'At Risk'
    elif r < 2 and f >= 4:
        return 'Cannot Lose Them'
    elif r < 3 and f < 2:
        return 'Hibernating'
    else:
        return 'Lost'

def create_rfm_visualizations(rfm, segment_stats):
    """Cria visualizações da análise RFM"""
    print("\n📊 Gerando visualizações...")
    
    # 1. Distribuição de segmentos
    plt.figure(figsize=(12, 6))
    segment_counts = rfm['segment'].value_counts()
    colors = plt.cm.Set3(range(len(segment_counts)))
    plt.pie(segment_counts, labels=segment_counts.index, autopct='%1.1f%%', 
            colors=colors, startangle=90)
    plt.title('Distribuição de Clientes por Segmento RFM', fontsize=14, weight='bold')
    save_plot('rfm_segment_distribution.png')
    
    # 2. Valor por segmento
    plt.figure(figsize=(12, 6))
    segment_stats_sorted = segment_stats.sort_values('total_value', ascending=True)
    plt.barh(segment_stats_sorted.index, segment_stats_sorted['total_value'])
    plt.xlabel('Valor Total (€)', fontsize=12)
    plt.title('Valor Total por Segmento RFM', fontsize=14, weight='bold')
    plt.grid(axis='x', alpha=0.3)
    for i, v in enumerate(segment_stats_sorted['total_value']):
        plt.text(v, i, f' €{v:,.0f}', va='center')
    save_plot('rfm_value_by_segment.png')
    
    # 3. Scatter RFM (Recency vs Frequency)
    plt.figure(figsize=(12, 8))
    for segment in rfm['segment'].unique():
        segment_data = rfm[rfm['segment'] == segment]
        plt.scatter(segment_data['recency'], segment_data['frequency'], 
                   label=segment, alpha=0.6, s=50)
    plt.xlabel('Recency (dias desde última compra)', fontsize=12)
    plt.ylabel('Frequency (número de compras)', fontsize=12)
    plt.title('Segmentação RFM: Recency vs Frequency', fontsize=14, weight='bold')
    plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.grid(alpha=0.3)
    save_plot('rfm_scatter.png')
    
    # 4. Heatmap de scores médios
    plt.figure(figsize=(10, 8))
    pivot_scores = rfm.groupby('segment')[['r_score', 'f_score', 'm_score']].mean()
    sns.heatmap(pivot_scores.T, annot=True, fmt='.2f', cmap='RdYlGn', 
                cbar_kws={'label': 'Score Médio'})
    plt.title('Scores RFM Médios por Segmento', fontsize=14, weight='bold')
    plt.ylabel('Métrica RFM', fontsize=12)
    plt.xlabel('Segmento', fontsize=12)
    save_plot('rfm_heatmap.png')

if __name__ == "__main__":
    df = load_data('ecommerce_clean.csv', config.DATA_PROCESSED)
    calculate_rfm(df)